from django.apps import AppConfig


class WebanalysisConfig(AppConfig):
    name = 'webanalysis'
