from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request,'webanalysis/index.html')

def upload(request):
    print(request.POST,'1')
    print(dir(request.POST.get('log')))
    # print(request.FILES,'2')
    return HttpResponse("上传成功")

